
import os
from pinecone import Pinecone
from sentence_transformers import SentenceTransformer


_pc = None
_index = None
_embedder = None


def _get_index():
    global _pc, _index
    api_key = os.getenv("PINECONE_API_KEY")
    index_name = os.getenv("PINECONE_INDEX_NAME")
    # Optional explicit host: https://<index>-<proj>.svc.<region>.pinecone.io
    # Accept common aliases to reduce misconfiguration
    host = (
        os.getenv("PINECONE_HOST")
        or os.getenv("PINECONE_HOST_URL")
        or os.getenv("HOST")
    )
    if not api_key:
        raise RuntimeError("PINECONE_API_KEY is not set in environment.")
    if not index_name:
        raise RuntimeError("PINECONE_INDEX_NAME is not set in environment.")
    if _pc is None:
        _pc = Pinecone(api_key=api_key)
    if _index is None:
        if host:
            try:
                _index = _pc.Index(index_name, host=host)
            except Exception as e:
                print(f"[pinecone_utils] Failed to use custom host '{host}': {e}. Falling back to default host resolution.")
                _index = _pc.Index(index_name)
        else:
            _index = _pc.Index(index_name)
    return _index


def _get_embedder():
    global _embedder
    if _embedder is None:
        _embedder = SentenceTransformer('all-MiniLM-L6-v2')
    return _embedder


def semantic_search(query, top_k=3):
    try:
        idx = _get_index()
        embedder = _get_embedder()
        query_emb = embedder.encode([query])[0].tolist()
        namespace = os.getenv("PINECONE_NAMESPACE")  # optional
        res = idx.query(
            vector=query_emb,
            top_k=top_k,
            include_metadata=True,
            namespace=namespace if namespace else None,
        )
        # Extract context and references from metadata
        results = []
        matches = res.get('matches', []) if isinstance(res, dict) else getattr(res, 'matches', [])
        for match in matches:
            context = None
            reference = None
            metadata = match.get('metadata', {}) if isinstance(match, dict) else getattr(match, 'metadata', {})
            if metadata:
                context = metadata.get('text') or metadata.get('context')
                reference = metadata.get('reference') or metadata.get('book') or metadata.get('source')
            if not context:
                # some SDKs may have 'text' at root
                if isinstance(match, dict) and 'text' in match:
                    context = match['text']
            if context:
                results.append({'context': context, 'reference': reference})
        return results
    except Exception as e:
        # Fail open: return no context so caller will fallback to direct LLM
        print(f"[pinecone_utils] semantic_search error: {e}")
        return []
