# SindoorAi-backend

Comprehensive backend for the SindoorAi assistant: REST endpoints for chat, code generation, resume analysis, and RAG-enhanced utilities. This repository wires together Flask endpoints, LLM vendors (Together AI, OpenAI), Pinecone for vector search, and lightweight resume ML models.

## Contents
- `app.py` - Main Flask application exposing the REST HTTP API.
- `ml_integration/` - Integration utilities and pipelines:
  - `pinecone_utils.py` - Pinecone client wrapper and `semantic_search` helper.
  - `resume.py` - Resume extraction, embedding (OpenAI), and prediction pipeline.
- `ml_models/` - Trained models (label encoder, XGBoost model) expected at runtime.
- `requirements.txt` - Python dependencies.
- `Procfile` - Example Procfile for Heroku/Gunicorn deployment.

## Quick summary
This backend provides the following features:
- /chat — Chat with (optionally) image support. Uses OpenAI GPT-4o-mini for chat and imgbb for image uploads.
- /code-gen — RAG-enabled code generation using Pinecone for context and Together AI for code generation (Qwen models used in code).
- /resume-analyze — Upload a resume (PDF/DOCX) to extract text, compute embeddings (OpenAI), predict a job role using a saved XGBoost model, and get a detailed LLM-based coaching analysis.
- /code-debug, /code-learn — Helpers that use semantic search + Together AI for debugging and teaching topics.

## Contract (inputs / outputs)
- Input: JSON for most endpoints. File upload (multipart/form-data) for `/resume-analyze`.
- Output: JSON responses containing `response` or `error` and additional fields like `context`, `references`, `role`, etc.
- Error handling: endpoints return 4xx for client errors and 500 for server side exceptions with `details` when available.

## Environment variables (required)
- `OPENAI_API_KEY` — OpenAI API key used in `resume.py` and `app.py` for embeddings/chat.
- `IMGBB_API_KEY` — imgbb API key for uploading images (optional if not using images).
- `TOGETHERAI_API_KEY` — API key for Together AI client used by code-generation endpoints.
- `PINECONE_API_KEY` — Pinecone API key for vector DB queries.
- `PINECONE_INDEX_NAME` — Pinecone index name.
- `PINECONE_HOST` (optional) — Full Pinecone host URL if needed.
- `PINECONE_NAMESPACE` (optional) — Namespace used in `pinecone_utils`.
- `PORT` (optional) — Port to run Flask app (default 5000).

## Setup (local)
1. Clone the repository and change to the project directory.
2. Create a virtualenv and activate it.

```powershell
python -m venv .venv; .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

3. Create a `.env` file in the project root with the required env vars. Example:

```
OPENAI_API_KEY=sk-...
TOGETHERAI_API_KEY=...
IMGBB_API_KEY=...
PINECONE_API_KEY=...
PINECONE_INDEX_NAME=your-index
PINECONE_HOST=https://<index>-<proj>.svc.<region>.pinecone.io
PINECONE_NAMESPACE=default
```

4. Place ML model artifacts in `ml_models/`:
- `label_encoder.pkl` — LabelEncoder used by resume classifier.
- `xgboost_resume_model.pkl` — Trained XGBoost model that expects embeddings as input.

5. Run the app locally:

```powershell
python app.py
```

Or use Gunicorn (Procfile is provided as a starting point):

```powershell
# On Windows, use python app.py for dev. For production on Linux use:
gunicorn app:app --bind 0.0.0.0:$PORT
```

## API Reference — short
See `docs/api.md` for full examples. Short list:
- POST /chat — JSON: `{ "query": "...", "image": "<base64 or url>" }`
- POST /code-gen — JSON: `{ "query": "..." }` returns generated code and used RAG context.
- POST /resume-analyze — multipart/form-data with `file` field. Returns predicted role, percentage and LLM analysis.
- POST /code-debug — JSON: `{ "code": "...", "error": "..." }`
- POST /code-learn — JSON: `{ "topic": "..." }`

## Architecture & data flow
See `docs/architecture.md` for an overview. In short:
- HTTP requests handled by Flask in `app.py`.
- RAG flow: `app.py` calls `ml_integration.pinecone_utils.semantic_search` to fetch context; if present, it includes these contexts in the prompt sent to Together AI.
- Resume flow: file -> `ml_integration.resume.extract_text_from_file` -> `encode_text_with_online_nlp` (OpenAI embeddings) -> `predict_resume_label` (XGBoost + LabelEncoder).

## Security & operational notes
- Never commit `.env` or API keys to source control.
- Monitor embedding and LLM usage — calls to OpenAI/Together and Pinecone may incur costs.
- Use rate limiting and authentication in front of these endpoints in production.

## Contributing
See `docs/contributing.md` for development workflow, tests, and coding style notes.

## License
This repo includes a `LICENSE` file. Follow the license terms for usage and contribution.

---

For detailed API examples, architecture diagram, deployment, and contributor guidance, see the `docs/` directory.
