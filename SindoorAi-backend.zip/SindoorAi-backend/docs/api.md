# API Reference

This document lists the HTTP endpoints exposed by `app.py` with examples.

Base URL: `http://<host>:<port>` (default `http://localhost:5000`)

---

## POST /chat
Description: Chat endpoint. Accepts text query and optional image data (base64 or URL). Uses OpenAI GPT model for chat.

Request JSON example:

```json
{
  "query": "What is the time complexity of quicksort?",
  "image": "https://.../image.jpg"
}
```

Response example:

```json
{
  "response": "Quicksort average complexity is O(n log n)...",
  "image_url": "https://.../image.jpg"
}
```

Errors: 400 for bad requests, 500 for server errors (see `details` field).

---

## POST /code-gen
Description: RAG-enabled code generation. Performs a semantic search in Pinecone and then calls Together AI to generate code.

Request JSON example:

```json
{ "query": "Create a fast Python function to merge two sorted lists" }
```

Response fields:
- `response` — generated text/code from the LLM.
- `context` — array of contexts returned by vector DB (may be empty).
- `references` — array of references extracted from metadata.
- `used_vectordb` — boolean indicating whether Pinecone returned results.

---

## POST /resume-analyze
Description: Analyze an uploaded resume file. Accepts `multipart/form-data` with a `file` key.

Curl example:

```bash
curl -F "file=@/path/to/resume.pdf" http://localhost:5000/resume-analyze
```

Response example:

```json
{
  "llm_analysis": "<detailed coaching analysis>",
  "role": "Data Scientist",
  "percentage": 87.45
}
```

Notes:
- The endpoint stores the uploaded file temporarily under `ml_models/` and expects model artifacts (label encoder and XGBoost model) to be present.

---

## POST /code-debug
Description: Send code and an error message; the service will use semantic search and Together AI to propose fixes.

Request JSON:

```json
{ "code": "def foo(): ...", "error": "IndexError: list index out of range" }
```

Response: JSON with `response`, `context`, `references`, `used_vectordb`.

---

## POST /code-learn
Description: Educational endpoint to explain topics in depth.

Request JSON:

```json
{ "topic": "How to design a high-throughput message queue" }
```

Response: JSON with `response` and optional `context` and `references`.

---

## Common response shape
- Success: HTTP 200 with JSON payload specific to endpoint.
- Client errors: HTTP 400 with `{ "error": "...", "details": "..." }`.
- Server errors: HTTP 500 with `{ "error": "Server error", "details": "<exception message>" }`.

For more detailed examples and sample client scripts, see the `examples/` folder (not included) or open an issue to request specific language SDK samples.
