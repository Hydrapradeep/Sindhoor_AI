# Architecture

This document explains components and how they interact.

## High level components
- Flask API (`app.py`) — HTTP endpoints and orchestration.
- Vector Database (Pinecone) — stores passages/contexts, queried by `pinecone_utils.semantic_search` for RAG.
- LLM Providers — Together AI (primary code-gen/debug/learn), OpenAI (embeddings & chat in some flows).
- Resume ML pipeline — `ml_integration/resume.py` extracts text, computes embeddings, and predicts using an XGBoost model and a label encoder.
- Storage — `ml_models/` stores trained models/artifacts that must be present on disk.

## Folder responsibilities
- `ml_integration/` — Local integrations: Pinecone utility and resume pipeline.
- `ml_models/` — Binary models and pickled encoders.
- `app.py` — Flask routes connecting utilities + LLM calls.

## Data flow examples
- Code generation (/code-gen): request -> semantic_search(query) -> prepare RAG prompt -> Together AI -> response returned.
- Resume analysis: upload file -> extract text -> compute embeddings (OpenAI) -> XGBoost classification -> Together AI provides coaching analysis.

## Key design notes
- `pinecone_utils` will "fail open" and return an empty list in case of errors. Endpoints then skip RAG and call LLMs directly.
- `resume.py` uses online OpenAI embeddings (`text-embedding-3-small`) and averages chunk embeddings to produce a single vector.
- The project mixes different LLM providers; ensure API keys and rate limits are handled appropriately.

## Extension points
- Add authentication (API keys, OAuth) in front of Flask endpoints.
- Add caching for repeated semantic queries.
- Support local embedding models for offline operation (e.g., use `sentence-transformers` on resumes to reduce OpenAI costs).

