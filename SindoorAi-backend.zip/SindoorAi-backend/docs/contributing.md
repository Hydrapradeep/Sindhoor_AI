# Contributing

Thanks for your interest in contributing! This page explains how to set up a dev environment, run tests, and submit changes.

## Developer setup
1. Fork and clone the repo.
2. Create a Python virtualenv and install dependencies:

```powershell
python -m venv .venv; .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

3. Create a `.env` with the required keys for local testing.

## Coding style
- Follow PEP8 for Python code.
- Keep functions small and single-responsibility.

## Adding or updating ML models
- Trained models go into `ml_models/`.
- Use `joblib.dump` to save scikit-learn/XGBoost objects.
- Ensure any model changes update `docs/architecture.md` and `README.md`.

## Tests
- Add unit tests next to modules (e.g., `tests/test_resume.py`).
- Use `pytest` as the test runner.

## PRs
- Open a PR to `main`. Include a clear description and link any issues.
- Include tests for new functionality.

## Security
- Do not commit credentials or large binary datasets.
- If you find a security issue, privately contact the maintainers rather than opening a public issue.

If you'd like help writing tests or shipping a new feature, open an issue and assign it to the maintainers.
