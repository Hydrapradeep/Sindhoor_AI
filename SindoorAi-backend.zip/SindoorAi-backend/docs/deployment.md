# Deployment Guide

This page includes guidance for deploying the backend to production.

## Supported deployment targets
- Heroku / any Docker container / Linux host with Gunicorn are common options. Procfile included as an example.

## Using Procfile (Heroku)
The repository includes `Procfile` with a web process. Heroku will use that to start Gunicorn.

Steps:
1. Ensure `requirements.txt` contains all dependencies.
2. Set required environment variables (`OPENAI_API_KEY`, `TOGETHERAI_API_KEY`, `PINECONE_API_KEY`, `PINECONE_INDEX_NAME`, etc.) in the platform settings.
3. Ensure `ml_models/` artifacts are available in your build or loaded at runtime (use an object store or a startup script to download them).

Notes:
- On Heroku, ephemeral filesystem means you cannot rely on runtime writes to persist across restarts. Save persistent artifacts in S3 or similar.
- For Gunicorn on Linux, use `gunicorn app:app --workers 3 --bind 0.0.0.0:$PORT`.

## Environment & secrets
- Use the platform's secrets manager or environment configuration for API keys.
- Rotate keys on schedule and set minimal permissions.

## Scaling & reliability
- Add a reverse-proxy / load-balancer in front of multiple app instances.
- Consider autoscaling based on CPU and request latency.
- Add healthcheck endpoints and readiness probes.

## Monitoring & logging
- Stream logs to a centralized service (Papertrail, Datadog, CloudWatch).
- Monitor LLM & embedding usage to track costs.

## Pinecone considerations
- Use the correct `PINECONE_HOST` for your cluster region if automatic host resolution fails.
- Configure `PINECONE_NAMESPACE` if you segment vectors by environment.

## Example Heroku deployment
1. Create Heroku app
2. Add config vars (env vars)
3. Push the repo
4. Ensure buildpack installs dependencies from `requirements.txt`

