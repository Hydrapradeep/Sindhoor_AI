import os
import uuid
from datetime import datetime

import psycopg2
import requests
from dotenv import load_dotenv

# Proper imports
from flask import Flask, jsonify, request
from flask_cors import CORS
from passlib.hash import bcrypt

# NEW: Supabase imports
from supabase import Client, create_client  # <-- add this
from together import Together

# Load environment variables from .env file
load_dotenv()

# Get API keys from environment
OPENAI_API_KEY = (os.getenv("OPENAI_API_KEY") or "").strip()
if not OPENAI_API_KEY.startswith(("sk-", "sk-proj-")):
    raise RuntimeError("OPENAI_API_KEY missing or malformed")
print("OPENAI_API_KEY prefix:", OPENAI_API_KEY[:12] + "…")

IMGBB_API_KEY = os.getenv("IMGBB_API_KEY")
TOGETHERAI_API_KEY = os.getenv("TOGETHERAI_API_KEY")

# NEW: Supabase env + client
SUPABASE_URL = os.getenv("SUPABASE_URL")  # <-- set in .env
SUPABASE_KEY = os.getenv("SUPABASE_KEY")  # <-- anon or service (server-only)
supabase: Client = create_client(
    SUPABASE_URL, SUPABASE_KEY
)  # per official init [web:33]

# Initialize Flask app
app = Flask(__name__)
CORS(app)


# =========================
# NEW: Auth endpoints
# =========================
# -----------------------------
# 🧩 SIGNUP ROUTE
# -----------------------------
@app.post("/auth/signup")
def auth_signup():
    try:
        data = request.get_json(force=True)
        email = (data.get("email") or "").strip()
        full_name = (data.get("full_name") or "").strip()
        password = data.get("password") or ""
        confirm_password = data.get("confirm_password") or ""

        if not email or not password or not confirm_password or not full_name:
            print("Validation failed: missing fields")
            return jsonify(
                {"error": "email, password, confirm_password, full_name are required"}
            ), 400  # require full_name

        if password != confirm_password:
            print("Validation failed: passwords do not match")
            return jsonify(
                {"error": "Passwords do not match"}
            ), 400  # bcrypt usage remains same

        # Check if user already exists
        existing = supabase.table("profiles").select("id").eq("email", email).execute()
        if existing.data and len(existing.data) > 0:
            return jsonify({"error": "Email already registered"}), 409  # select + eq

        # Hash password securely
        password_hash = bcrypt.hash(password)  # passlib bcrypt hash
        user_id = str(uuid.uuid4())

        # Insert user into Supabase database
        try:
            print(f"Attempting to insert new profile for {email}")
            supabase.table("profiles").insert(
                {
                    "id": user_id,
                    "email": email,
                    "full_name": full_name,  # NEW field persisted
                    "password_hash": password_hash,
                    "created_at": datetime.utcnow().isoformat(),
                    "updated_at": datetime.utcnow().isoformat(),
                }
            ).execute()  # insert pattern
            print("Profile insertion successful.")
        except Exception as e:
            print(f"CRITICAL: Database insertion failed: {e}")
            return jsonify({"error": "Failed to create user"}), 500

        return jsonify(
            {
                "user_id": user_id,
                "full_name": full_name,
                "message": "Sign up successful.",
            }
        ), 201
    except Exception as e:
        print(f"An unexpected error occurred in /auth/signup: {e}")
        return jsonify({"error": "An unexpected server error occurred."}), 500


# -----------------------------
# 🔐 LOGIN ROUTE
# -----------------------------
@app.post("/auth/login")
def auth_login():
    try:
        data = request.get_json(force=True)
        email = (data.get("email") or "").strip()
        password = data.get("password") or ""

        if not email or not password:
            return jsonify({"error": "email and password are required"}), 400

        # Fetch user from Supabase (include full_name)
        resp = (
            supabase.table("profiles")
            .select("id, password_hash, full_name")
            .eq("email", email)
            .execute()
        )  # select + eq

        users = resp.data
        if not users or len(users) == 0:
            print("Login failed: no user found for this email")
            return jsonify({"error": "Invalid credentials"}), 401

        user = users[0]
        user_id = user.get("id")
        stored_hash = user.get("password_hash")

        # Verify password
        if not bcrypt.verify(password, stored_hash):
            print("Login failed: wrong password")
            return jsonify({"error": "Invalid credentials"}), 401  # passlib verify

        print(f"Login successful for user {email}")
        return jsonify(
            {
                "user_id": user_id,
                "full_name": user.get("full_name"),
                "message": "Login successful.",
            }
        ), 200
    except Exception as e:
        print(f"An unexpected error occurred in /auth/login: {e}")
        return jsonify({"error": "An unexpected server error occurred."}), 500


@app.get("/user/<user_id>")
def get_user(user_id):
    try:
        resp = (
            supabase.table("profiles")
            .select("email, full_name")
            .eq("id", user_id)
            .execute()
        )
        if not resp.data:
            return jsonify({"error": "User not found"}), 404
        return jsonify(
            {"email": resp.data[0]["email"], "full_name": resp.data[0]["full_name"]}
        ), 200
    except Exception as e:
        print(f"Error fetching user: {e}")
        return jsonify({"error": "Server error"}), 500


# -------------------------
# Your existing endpoints
# -------------------------


# /chat endpoint for chat and chat-with-image, using OpenAI GPT-4o mini and imgbb for image upload
@app.route("/chat", methods=["POST", "GET"])
def chat():
    try:
        data = request.get_json(force=True)
        user_query = data.get("query")
        image_data = data.get("image")  # Expecting base64 string if present

        # NEW: Validate that at least one of query, image, or image_url is present
        if not user_query and not image_data and not data.get("image_url"):
            return jsonify(
                {
                    "error": "At least one of 'query', 'image', or 'image_url' is required"
                }
            ), 400

        # Accept either base64 image, direct imgbb URL, or 'image_url' key
        image_url = None
        # Support both 'image' (base64 or url) and 'image_url' (url) keys
        if data.get("image_url"):
            image_url = data["image_url"]
        elif image_data:
            if isinstance(image_data, str) and image_data.strip().startswith("http"):
                image_url = image_data.strip()
            else:
                imgbb_url = "https://api.imgbb.com/1/upload"
                payload = {"key": IMGBB_API_KEY, "image": image_data}
                imgbb_response = requests.post(imgbb_url, data=payload)
                if imgbb_response.status_code == 200:
                    image_url = imgbb_response.json()["data"]["display_url"]
                else:
                    return jsonify(
                        {"error": "Image upload failed", "details": imgbb_response.text}
                    ), 400

        # Prepare messages for OpenAI GPT-4o mini
        messages = []
        if user_query:
            messages.append({"role": "user", "content": user_query})
        if image_url:
            # Pass image as an image block, not as text
            messages.append(
                {
                    "role": "user",
                    "content": [{"type": "image_url", "image_url": {"url": image_url}}],
                }
            )

        # Call OpenAI GPT-4o mini model (use correct model name for mini)
        openai_url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {OPENAI_API_KEY}",
            "Content-Type": "application/json",
        }
        payload = {"model": "gpt-4o-mini", "messages": messages}
        openai_response = requests.post(openai_url, headers=headers, json=payload)
        if openai_response.status_code == 200:
            result = openai_response.json()
            answer = result["choices"][0]["message"]["content"]
            return jsonify({"response": answer, "image_url": image_url})
        else:
            print(f"OpenAI API error: {openai_response.text}")
            return jsonify(
                {
                    "response": None,
                    "error": "LLM_unavailable",
                    "details": "Chat temporarily unavailable. Try again later.",
                    "image_url": image_url,
                }
            ), 200
    except Exception as e:
        return jsonify({"error": "Server error", "details": str(e)}), 500


from werkzeug.utils import secure_filename

# Pinecone semantic search utility
from ml_integration.pinecone_utils import semantic_search
from ml_integration.resume import process_resume


# /code-gen endpoint for semantic search + code generation
@app.route("/code-gen", methods=["POST", "GET"])
def code_gen():
    try:
        data = request.get_json(force=True)
        user_query = data.get("query")
        if not user_query:
            return jsonify({"error": "No query provided"}), 400

        # 1. Semantic search from Pinecone
        results = semantic_search(user_query, top_k=3)
        has_context = bool(results)
        context_str = (
            "\n---\n".join([r["context"] for r in results if r["context"]])
            if has_context
            else ""
        )
        references = (
            [r["reference"] for r in results if r.get("reference")]
            if has_context
            else []
        )

        # 2. Compose prompt for Together AI
        if has_context:
            prompt = f"""
You are the world’s best software engineer and architect, with mastery in all programming languages, data structures & algorithms, AI/ML, deep learning, generative AI, RAG systems, and modern software development practices.

Your responsibilities:

Always produce clean, efficient, and optimized code with best practices for readability, maintainability, and performance.

When solving problems, explain reasoning step-by-step before showing the final solution.

For coding tasks, provide the most elegant solution possible (avoiding redundancy, unnecessary complexity, or outdated methods).

If multiple approaches exist, explain trade-offs and recommend the best one.

Always assume the user may later need to scale the solution to enterprise-grade applications.

Keep answers up-to-date with the latest frameworks, libraries, and industry standards.

Think like a senior engineer + research scientist + system designer who is practical, innovative, and detail-oriented.

Your final output should empower the user with the best possible solution — not just working code, but production-ready, optimized implementations with clear explanations.

Context:
{context_str}

User Query:
{user_query}
"""
        else:
            prompt = f"""
You are the world’s best software engineer and architect, with mastery in all programming languages, data structures & algorithms, AI/ML, deep learning, generative AI, RAG systems, and modern software development practices.

Your responsibilities:

Always produce clean, efficient, and optimized code with best practices for readability, maintainability, and performance.

When solving problems, explain reasoning step-by-step before showing the final solution.

For coding tasks, provide the most elegant solution possible (avoiding redundancy, unnecessary complexity, or outdated methods).

If multiple approaches exist, explain trade-offs and recommend the best one.

Always assume the user may later need to scale the solution to enterprise-grade applications.

Keep answers up-to-date with the latest frameworks, libraries, and industry standards.

Think like a senior engineer + research scientist + system designer who is practical, innovative, and detail-oriented.

Your final output should empower the user with the best possible solution — not just working code, but production-ready, optimized implementations with clear explanations.

User Query:
{user_query}
"""

        client = Together(api_key=os.getenv("TOGETHERAI_API_KEY"))
        response = client.chat.completions.create(
            model="Qwen/Qwen2.5-Coder-32B-Instruct",
            messages=[{"role": "user", "content": prompt}],
        )
        code_response = (
            response.choices[0].message.content
            if hasattr(response, "choices") and response.choices
            else None
        )
        return jsonify(
            {
                "response": code_response,
                "context": [r["context"] for r in results],
                "references": references,
                "used_vectordb": has_context,
            }
        )
    except Exception as e:
        return jsonify({"error": "Server error", "details": str(e)}), 500


# /resume-analyze endpoint for resume file upload and ML prediction using local embedding model
@app.route("/resume-analyze", methods=["POST", "GET"])
def resume_analyze():
    try:
        if "file" not in request.files:
            return jsonify({"error": "No file part in the request"}), 400
        file = request.files["file"]
        if file.filename == "":
            return jsonify({"error": "No selected file"}), 400
        filename = secure_filename(file.filename)
        temp_path = os.path.join("ml_models", filename)
        file.save(temp_path)

        # Process the resume to get embedding, label, and text
        result = process_resume(temp_path)

        # Get prediction probability (percentage) for the top role
        import numpy as np

        from ml_integration import resume as resume_module

        label_encoder = resume_module.joblib.load(resume_module.LABEL_ENCODER_PATH)
        xgb_model = resume_module.joblib.load(resume_module.XGB_MODEL_PATH)
        embedding = result["embedding"]
        proba = xgb_model.predict_proba([embedding])[0]
        top_idx = np.argmax(proba)
        top_label = label_encoder.inverse_transform([top_idx])[0]
        top_percent = round(float(proba[top_idx]) * 100, 2)

        label = result["label"]
        text = result["text"]
        prompt = f"""
You are an expert career coach and hiring manager with 20 years of experience. Analyze the following resume text and the predicted job role. Provide:
1. A brief explanation of why the model predicted this role.
2. The strengths of the resume for this role.
3. The weaknesses of the resume for this role.
4. Advice for improving the resume for the top 2 most likely roles (the predicted role and one other likely role, e.g., Data Scientist and Backend Engineer). Suggest specific improvements for each role.

Resume text:
{text}

Predicted top role: {label} ({top_percent}%)
"""

        client = Together(api_key=os.getenv("TOGETHERAI_API_KEY"))
        llm_response = client.chat.completions.create(
            model="meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8",
            messages=[{"role": "user", "content": prompt}],
        )
        llm_content = (
            llm_response.choices[0].message.content
            if hasattr(llm_response, "choices") and llm_response.choices
            else None
        )

        return jsonify(
            {"llm_analysis": llm_content, "role": label, "percentage": top_percent}
        )
    except Exception as e:
        return jsonify({"error": "Server error", "details": str(e)}), 500


# /code-debug endpoint for code error correction and improvement
@app.route("/code-debug", methods=["POST", "GET"])
def code_debug():
    try:
        data = request.get_json(force=True)
        code = data.get("code")
        error = data.get("error")
        if not code or not error:
            return jsonify({"error": "Both code and error fields are required."}), 400

        # Semantic search for debugging context
        query = f"Error: {error}\nCode:\n{code}"
        results = semantic_search(query, top_k=3)
        has_context = bool(results)
        context_str = (
            "\n---\n".join([r["context"] for r in results if r["context"]])
            if has_context
            else ""
        )
        references = (
            [r["reference"] for r in results if r.get("reference")]
            if has_context
            else []
        )

        # Prompt for Together AI
        if has_context:
            prompt = f"""
You are a world-class code reviewer and debugger. Given the following code and error message, identify the root cause, provide a corrected code snippet, and suggest improvements. Use the provided context if relevant.

Context:
{context_str}

Code:
{code}

Error:
{error}
"""
        else:
            prompt = f"""
You are a world-class code reviewer and debugger. Given the following code and error message, identify the root cause, provide a corrected code snippet, and suggest improvements.

Code:
{code}

Error:
{error}
"""

        client = Together(api_key=os.getenv("TOGETHERAI_API_KEY"))
        response = client.chat.completions.create(
            model="Qwen/Qwen2.5-Coder-32B-Instruct",
            messages=[{"role": "user", "content": prompt}],
        )
        debug_response = (
            response.choices[0].message.content
            if hasattr(response, "choices") and response.choices
            else None
        )
        return jsonify(
            {
                "response": debug_response,
                "context": [r["context"] for r in results],
                "references": references,
                "used_vectordb": has_context,
            }
        )
    except Exception as e:
        return jsonify({"error": "Server error", "details": str(e)}), 500


# /code-learn endpoint for learning coding/system design topics
@app.route("/code-learn", methods=["POST", "GET"])
def code_learn():
    try:
        data = request.get_json(force=True)
        topic = data.get("topic")
        if not topic:
            return jsonify({"error": "No topic provided."}), 400

        # Semantic search for learning context
        results = semantic_search(topic, top_k=3)
        has_context = bool(results)
        context_str = (
            "\n---\n".join([r["context"] for r in results if r["context"]])
            if has_context
            else ""
        )
        references = (
            [r["reference"] for r in results if r.get("reference")]
            if has_context
            else []
        )

        # Prompt for Together AI
        if has_context:
            prompt = f"""
You are a senior software engineer and educator. Teach the following topic in detail, using the provided context as reference. Include practical examples, best practices, and up-to-date information.

Context:
{context_str}

Topic:
{topic}
"""
        else:
            prompt = f"""
You are a senior software engineer and educator. Teach the following topic in detail. Include practical examples, best practices, and up-to-date information.

Topic:
{topic}
"""

        client = Together(api_key=os.getenv("TOGETHERAI_API_KEY"))
        response = client.chat.completions.create(
            model="Qwen/Qwen2.5-Coder-32B-Instruct",
            messages=[{"role": "user", "content": prompt}],
        )
        learn_response = (
            response.choices[0].message.content
            if hasattr(response, "choices") and response.choices
            else None
        )
        return jsonify(
            {
                "response": learn_response,
                "context": [r["context"] for r in results],
                "references": references,
                "used_vectordb": has_context,
            }
        )
    except Exception as e:
        return jsonify({"error": "Server error", "details": str(e)}), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
