from dotenv import load_dotenv
load_dotenv()

from pinecone import Pinecone
import os
pc = Pinecone(api_key=os.getenv("PINECONE_API_KEY"))
idx = pc.Index(os.getenv("PINECONE_INDEX_NAME"), host=os.getenv("PINECONE_HOST"))
print(idx.describe_index_stats())